(function () {
    var baseWith = document.body.clientWidth;

    /*
    * 采购金额Top5(横向柱状图)
    * */
    var purchAmountChart = function (div, rate, arr, text) {
        var myChart = echarts.init(document.getElementById('purch-amount'));
        myChart.setOption({
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            // 调整图表位置
            grid: {
                top: "5%",
                left: '3%',
                right: '4%',
                bottom: '0%',
                containLabel: true
            },
            xAxis: {
                show: false,
                type: 'value',
                boundaryGap: [0, 0.01],
                splitLine: {
                    show: false // 去掉网格线
                },
                // y 轴线
                axisLine: {
                    show: false,
                },
                // 刻度
                axisTick: {
                    show: false
                },
            },
            yAxis: {
                type: 'category',
                data: ['其他', '护层', '绝缘层', '钢', '铝', '铜'],
                splitLine: {
                    show: false // 去掉网格线
                },
                // y 轴线
                axisLine: {
                    show: false,
                },
                // 刻度
                axisTick: {
                    show: false
                },
                // 文字与轴线的距离
                axisLabel: {
                    margin: 20,
                    textStyle: {
                        color: '#ffffff',
                        fontSize: '12'
                    },
                },
            },
            series: [
                {
                    name: '材质',
                    type: 'bar',
                    barWidth: 12,//柱图宽度

                    label: {
                        normal: {
                            show: true,
                            formatter: '{c}万',
                            position: 'right',//数据展示方向
                        }
                    },
                    data: [534.64, 672.58, 734.64, 1052.70, 1437.20, 1560.20],
                    itemStyle: {
                        normal: {
                            barBorderRadius: 10,
                            color: function (params) {
                                var colorList = [
                                    '#EF4F7C', '#13CDB9', '#4447D1', '#3099FD', '#CF891D', '#674AFD',
                                ];
                                return colorList[params.dataIndex]
                            },
                        },
                        emphasis: {
                            label: {
                                show: false,
                                textStyle: {
                                    fontSize: 12
                                }

                            }
                        }
                    },
                },
            ]
        });
        $(window).resize(function () {
            myChart.resize();
        });
    };
    purchAmountChart();


    /*
    * 大类占比（饼状图）
    *
    * */
    var largeClassRatioChart = function () {
        var colors = ['rgb(103,74,253)', 'rgb(19,205,185)', 'rgb(207,137,29)', 'rgb(48,153,253)', 'rgb(239,79,124)', 'rgb(68,71,209)'];
        var myChart = echarts.init(document.getElementById('large-class-ratio'));
        myChart.setOption({

            // 调整图表位置
            grid: {
                top: "5%",
                left: '0%',
                right: '0%',
                bottom: '0%',
                containLabel: true
            },

            // backgroundColor: '#2c343c',
            color: colors,

            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },

            visualMap: {
                show: false,
                min: 80,
                max: 600,
                inRange: {
                    colorLightness: [0, 1]
                }
            },
            series: [
                {
                    name: '访问来源',
                    type: 'pie',
                    radius: '73%',
                    center: ['50%', '50%'],
                    data: [
                        {value: 335, name: '铜 335万'},
                        {value: 310, name: '护层 310万'},
                        {value: 274, name: '铝 274万'},
                        {value: 235, name: '钢 235万'},
                        {value: 400, name: '其他 400万'},
                        {value: 400, name: '绝缘层 400万'}
                    ].sort(function (a, b) {
                        return a.value - b.value;
                    }),
                    roseType: 'radius',
                    label: {
                        normal: {
                            padding: [0, -120, 0, -130],
                            formatter: '{b}（{d}%）\n\n',
                            textStyle: {
                                color: 'rgba(255, 255, 255,1)'
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            smooth: 0.2,
                            length: baseWith / 40, // 第一条引导线的长
                            length2: baseWith / 10, //第二条引导线的长
                        }
                    },
                    itemStyle: {
                        normal: {
                            shadowBlur: 200,
                        }
                    },

                    animationType: 'scale',
                    animationEasing: 'elasticOut',
                    animationDelay: function (idx) {
                        return Math.random() * 200;
                    }
                }
            ]
        });
        $(window).resize(function () {
            myChart.resize();
        });
    };
    largeClassRatioChart();

    /*
    *物料采购（折线图）
    *
    * */

    var materialPurChart = function () {
        var myChart = echarts.init(document.getElementById('material-pur'));
        myChart.setOption({
                grid: {
                    borderColor: ['yellow'],
                    backgroundColor: ['yellow'],
                },
                color: ["#674AFD", "#CF891D", "#3099FD", "#4447D1", "#13CDB9", "#EF4F7C"],
                // 图例
                legend: {
                    data: ['铜', '铝', '钢', '绝缘体', '护层', '其他'],
                    bottom: 0,
                    left: 30,
                    icon: 'rect',
                    textStyle: {
                        fontSize: 15,
                        color: '#fff'
                    },
                    padding: [0, 10, 5,0]
                },

                xAxis: {
                    boundaryGap: false, // 从原点开始
                    type: 'category',
                    data: ['1', '2', '3', '4', '5', '6', '7'],
                    axisTick: {
                        show: false, // 是否显示x轴刻度
                    },
                    axisLabel: {
                        textStyle: {
                            color: '#fff',
                        },
                        margin: 10,//刻度标签与轴线之间的距离。
                    },
                    splitLine: {
                        show: false // 去掉网格线
                    },
                },
                yAxis: {
                    type: 'value',
                    axisLabel: {
                        formatter: '{value}万',
                        textStyle: {
                            color: '#fff'
                        }
                    },
                    axisLine: {
                        show: false, // 是否显示y轴轴线
                    },
                    axisTick: {
                        show: false, // 是否显示y轴刻度
                    },
                    splitLine: {
                        show: true, // 网格线是否显示
                        lineStyle:{ // 设置网格线颜色
                            color: ["#222532"]
                        }
                    },
                },
                series: [
                    {
                        name: "铜",
                        data: [820, 932, 901, 934, 1290, 1330, 1320],
                        type: 'line',
                        smooth: true, // true 表示光滑的曲线
                        symbolSize: 0, // 拐点圆的大小
                        lineStyle: {
                            normal: {
                                color: "#674AFD",
                                width: 4, // 线的粗细
                            }
                        }
                    },
                    {
                        name: "铝",
                        data: [120, 432, 501, 964, 3290, 1330, 5320],
                        type: 'line',
                        smooth: true, // true 表示光滑的曲线
                        symbolSize: 0, // 拐点圆的大小
                        lineStyle: {
                            normal: {
                                color: "#CF891D",
                                width: 4,// 线的粗细
                            }
                        }
                    },
                    {
                        name: "钢",
                        data: [123, 245, 453, 234, 133, 131, 123],
                        type: 'line',
                        smooth: true, // true 表示光滑的曲线
                        symbolSize: 0, // 拐点圆的大小
                        lineStyle: {
                            normal: {
                                color: "#3099FD",
                                width: 4,// 线的粗细
                            }
                        }
                    },
                    {
                        name: "绝缘体",
                        data: [1234, 3134, 1231, 1314, 1233, 1330, 1320],
                        type: 'line',
                        smooth: true, // true 表示光滑的曲线
                        symbolSize: 0, // 拐点圆的大小
                        lineStyle: {
                            normal: {
                                color: "#4447D1",
                                width: 4,// 线的粗细
                            }
                        }
                    },
                    {
                        name: "护层",
                        data: [554, 454, 454, 344, 546, 564, 324],
                        type: 'line',
                        smooth: true, // true 表示光滑的曲线
                        symbolSize: 0, // 拐点圆的大小
                        lineStyle: {
                            normal: {
                                color: "#13CDB9",
                                width: 4,// 线的粗细
                            }
                        }
                    },
                    {
                        name: "其他",
                        data: [767, 878, 879, 657, 567, 677, 878],
                        type: 'line',
                        smooth: true, // true 表示光滑的曲线
                        symbolSize: 0, // 拐点圆的大小
                        lineStyle: {
                            normal: {
                                color: "#EF4F7C",
                                width: 4,// 线的粗细
                            }
                        }
                    }
                ]
            }
        );
        $(window).resize(function () {
            myChart.resize();
        });
    };
    materialPurChart();

    /*
    * 采购金额同比
    *
    * */
    var purCompared = function () {
        var myChart = echarts.init(document.getElementById('pur-compared'));
        myChart.setOption({
            // 调整图表位置
            grid: {
                top: "9%",
                left: '5%',
                right: '5%',
                bottom: '9%',
                containLabel: true
            },


            legend: {
                itemWidth: 15,
                itemHeight: 15,
                data: ['2016', '2017', '2018'],
                icon: 'rect',
                textStyle: {
                    fontSize: 15,
                    color: '#fff'
                },
                bottom: 0,
                left: 30,
            },
            xAxis: {
                data: ["1月", "2月", "3月", "4月", "5月", "6月","7月", "8月", "9月", "10月", "11月", "12月"],
                splitLine: {
                    show: false,
                },
                axisTick: {
                    show: false, // 是否显示x轴刻度
                },
                axisLabel: {
                    textStyle: {
                        color: '#fff',
                    }
                },
            },
            yAxis: {

                axisLine: {
                    show: false, // 是否显示y轴轴线
                },
                axisTick: {
                    show: false, // 是否显示y轴刻度
                },
                axisLabel: {
                    formatter: '{value}万',
                    textStyle: {
                        color: '#fff'
                    }
                },
                splitLine: {
                    show: true, // 网格线是否显示
                    lineStyle:{ // 设置网格线颜色
                        color: ["#222532"]
                    }
                },
            },
            series: [{
                name: '2016',
                type: 'bar',
                stack: '使用情况',
                data: [5, 20, 36, 10, 10, 20,5, 20, 36, 10, 10, 20],
                itemStyle: {
                    normal: {color: "#4447D1"},
                }
            }, {
                name: '2017',
                type: 'bar',
                stack: '使用情况',
                data: [40, 22, 18, 35, 42, 40,40, 22, 18, 35, 42, 40],
                itemStyle: {
                    normal: {color: "#13CDB9"},
                }
            },
                {
                    name: '2018',
                    type: 'bar',
                    stack: '使用情况',
                    data: [45, 27, 23, 40, 47, 45,45, 27, 23, 40, 47, 45],
                    itemStyle: {
                        normal: {color: "#3099FD"},
                    }
                }]
        });
        $(window).resize(function () {
            myChart.resize();
        });
    };
    purCompared();
})();
