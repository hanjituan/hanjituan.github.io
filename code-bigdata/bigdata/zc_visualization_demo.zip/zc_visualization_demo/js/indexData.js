var indexData = [
    {
        // 销售区占比
        areaRatio: {
            count: 30,
            list: [
                {name: "华东", value: 20},
                {name: "华中", value: 50},
                {name: "华北", value: 30},
                {name: "华南", value: 10},
                {name: "东北", value: 30},
                {name: "西南", value: 10},
                {name: "西北", value: 50},
            ]
        },
        // TOP5产品排行
        proRank: [
            {name: '110～220kV高压交联电缆', price: "384,529,403"},
            {name: '轨道交通车辆用电缆', price: "293,711,083"},
            {name: '交联聚乙烯绝缘船用电力电缆', price: "254,529,403"},
            {name: '交联聚乙烯绝缘船用通信电缆', price: "213,711,083"},
            {name: '橡皮绝缘船用电力电缆', price: "114,529,403"}
        ],
        // 区域销售金额
        areaSales: [130, 240, 450, 50, 40, 100, 90], // 11,0
        // 年度订单金额
        yearAreaSale: [
            {name: "东北", value: 0},
            {name: "华北", value: 1000000},
            {name: "西北", value: 0},
            {name: "华东", value: 0},
            {name: "华中", value: 0},
            {name: "华南", value: 0},
            {name: "西南", value: 100}
        ],
        // 销售目标达成率
        saleReachRate: [100, 190],
        // TOP5客户排行
        cusRank: [
            {name: '客户10', price: "514,529,403"},
            {name: '客户1', price: "493,711,083"},
            {name: '客户3', price: "314,529,403"},
            {name: '客户8', price: "293,711,083"},
            {name: '客户7', price: "214,529,403"}
        ],
        // 区域达成率
        areaReachRate: [10, 20, 32, 2, 28, 12, 90]
    },
    {
        // 销售区占比
        areaRatio: {
            count: 40,
            list: [
                {name: "华东", value: 20},
                {name: "华中", value: 50},
                {name: "华北", value: 30},
                {name: "华南", value: 10},
                {name: "东北", value: 30},
                {name: "西南", value: 10},
                {name: "西北", value: 50},
            ]
        },
        // TOP5产品排行
        proRank: [
            {name: '110～220kV高压交联电缆', price: "384,529,403"},
            {name: '轨道交通车辆用电缆', price: "293,711,083"},
            {name: '交联聚乙烯绝缘船用电力电缆', price: "254,529,403"},
            {name: '交联聚乙烯绝缘船用通信电缆', price: "213,711,083"},
            {name: '橡皮绝缘船用电力电缆', price: "114,529,403"}
        ],
        // 区域销售金额
        areaSales: [130, 240, 450, 100, 90, 100, 90], //12,1
        // 年度订单金额
        yearAreaSale: [
            {name: "东北", value: 1100000},
            {name: "华北", value: 0},
            {name: "西北", value: 0},
            {name: "华东", value: 0},
            {name: "华中", value: 0},
            {name: "华南", value: 0},
            {name: "西南", value: 0}
        ],
        // 销售目标达成率
        saleReachRate: [100, 210],
        // TOP5客户排行
        cusRank: [
            {name: '客户1', price: "3,145,529,403"},
            {name: '客户6', price: "2,933,711,083"},
            {name: '客户3', price: "314,529,403"},
            {name: '客户8', price: "293,711,083"},
            {name: '客户7', price: "214,529,403"}
        ],
        // 区域达成率
        areaReachRate: [10, 30, 32, 2, 88, 12, 90]
    },
    {
        // 销售区占比
        areaRatio: {
            count: 60,
            list: [
                {name: "华东", value: 20},
                {name: "华中", value: 50},
                {name: "华北", value: 30},
                {name: "华南", value: 10},
                {name: "东北", value: 30},
                {name: "西南", value: 10},
                {name: "西北", value: 50},
            ]
        },
        // TOP5产品排行
        proRank: [
            {name: '110～220kV高压交联电缆', price: "384,529,403"},
            {name: '轨道交通车辆用电缆', price: "293,711,083"},
            {name: '交联聚乙烯绝缘船用电力电缆', price: "254,529,403"},
            {name: '交联聚乙烯绝缘船用通信电缆', price: "213,711,083"},
            {name: '橡皮绝缘船用电力电缆', price: "114,529,403"}
        ],
        // 区域销售金额
        areaSales: [130, 240, 450, 200, 90, 100, 90], //22,1
        // 年度订单金额
        yearAreaSale: [
            {name: "东北", value: 0},
            {name: "华北", value: 10000000},
            {name: "西北", value: 0},
            {name: "华东", value: 10},
            {name: "华中", value: 0},
            {name: "华南", value: 0},
            {name: "西南", value: 0}
        ],
        // 销售目标达成率
        saleReachRate: [100, 750],
        // TOP5客户排行
        cusRank: [
            {name: '客户1', price: "3,145,529,403"},
            {name: '客户6', price: "2,933,711,083"},
            {name: '客户3', price: "314,529,403"},
            {name: '客户8', price: "293,711,083"},
            {name: '客户7', price: "214,529,403"}
        ],
        // 区域达成率
        areaReachRate: [10, 70, 36, 22, 28, 12, 90]
    },
    {
        // 销售区占比
        areaRatio: {
            count: 80,
            list: [
                {name: "华东", value: 20},
                {name: "华中", value: 50},
                {name: "华北", value: 30},
                {name: "华南", value: 10},
                {name: "东北", value: 30},
                {name: "西南", value: 10},
                {name: "西北", value: 50},
            ]
        },
        // TOP5产品排行
        proRank: [
            {name: '110～220kV高压交联电缆', price: "384,529,403"},
            {name: '轨道交通车辆用电缆', price: "293,711,083"},
            {name: '交联聚乙烯绝缘船用电力电缆', price: "254,529,403"},
            {name: '交联聚乙烯绝缘船用通信电缆', price: "213,711,083"},
            {name: '橡皮绝缘船用电力电缆', price: "114,529,403"}
        ],
        // 区域销售金额
        areaSales: [330, 440, 450, 400, 490, 100, 90], //34,1
        // 年度订单金额
        yearAreaSale: [
            {name: "东北", value: 0},
            {name: "华北", value: 0},
            {name: "西北", value: 12000000},
            {name: "华东", value: 0},
            {name: "华中", value: 0},
            {name: "华南", value: 10},
            {name: "西南", value: 0}
        ],
        // 销售目标达成率
        saleReachRate: [100, 620],
        // TOP5客户排行
        cusRank: [
            {name: '客户8', price: "4,145,529,403"},
            {name: '客户2', price: "3,933,711,083"},
            {name: '客户3', price: "214,529,403"},
            {name: '客户5', price: "173,711,083"},
            {name: '客户7', price: "164,529,403"}
        ],
        // 区域达成率
        areaReachRate: [80, 20, 32, 62, 6, 92, 90]
    },
    {
        // 销售区占比
        areaRatio: {
            count: 10,
            list: [
                {name: "华东", value: 20},
                {name: "华中", value: 50},
                {name: "华北", value: 30},
                {name: "华南", value: 10},
                {name: "东北", value: 30},
                {name: "西南", value: 10},
                {name: "西北", value: 50},
            ]
        },
        // TOP5产品排行
        proRank: [
            {name: '110～220kV高压交联电缆', price: "384,529,403"},
            {name: '轨道交通车辆用电缆', price: "293,711,083"},
            {name: '交联聚乙烯绝缘船用电力电缆', price: "254,529,403"},
            {name: '交联聚乙烯绝缘船用通信电缆', price: "213,711,083"},
            {name: '橡皮绝缘船用电力电缆', price: "114,529,403"}
        ],
        // 区域销售金额
        areaSales: [430, 440, 950, 400, 890, 100, 90], //44,1
        // 年度订单金额
        yearAreaSale: [
            {name: "东北", value: 0},
            {name: "华北", value: 0},
            {name: "西北", value: 0},
            {name: "华东", value: 0},
            {name: "华中", value: 0},
            {name: "华南", value: 10000000},
            {name: "西南", value: 0}
        ],
        // 销售目标达成率
        saleReachRate: [20, 100],
        // TOP5客户排行
        cusRank: [
            {name: '客户8', price: "4,145,529,403"},
            {name: '客户2', price: "3,933,711,083"},
            {name: '客户3', price: "214,529,403"},
            {name: '客户5', price: "173,711,083"},
            {name: '客户7', price: "164,529,403"}
        ],
        // 区域达成率
        areaReachRate: [13, 20, 52, 43, 28, 12, 90]
    }
];